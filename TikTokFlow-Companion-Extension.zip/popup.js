// TikTokFlow Companion - Popup Controller

document.addEventListener("DOMContentLoaded", async () => {
  // Elements
  const statusPill = document.getElementById("statusPill");
  const statusPillText = document.getElementById("statusPillText");
  const memberNameText = document.getElementById("memberNameText");
  const serverUrlText = document.getElementById("serverUrlText");

  const userAvatar = document.getElementById("userAvatar");
  const userHandle = document.getElementById("userHandle");
  const userNickname = document.getElementById("userNickname");
  const statFollowers = document.getElementById("statFollowers");
  const statVideos = document.getElementById("statVideos");
  const statRevenue = document.getElementById("statRevenue");

  const gpmIndicator = document.getElementById("gpmIndicator");
  const gpmStatusText = document.getElementById("gpmStatusText");
  const gpmProfileCount = document.getElementById("gpmProfileCount");
  const serverScheduleText = document.getElementById("serverScheduleText");
  const syncNowBtn = document.getElementById("syncNowBtn");
  const syncBtnText = document.getElementById("syncBtnText");
  const lastSyncText = document.getElementById("lastSyncText");

  function formatNumber(num) {
    if (!num || isNaN(num)) return "0";
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
    if (num >= 1000) return (num / 1000).toFixed(1) + "K";
    return num.toLocaleString();
  }

  function formatMoney(amount) {
    if (!amount || isNaN(amount)) return "$0.00";
    return `$${Number(amount).toFixed(2)}`;
  }

  // 1. Load config from config.json if storage is empty
  let data = await chrome.storage.local.get([
    "serverUrl",
    "personalToken",
    "memberName",
    "userEmail",
    "latestAccount",
    "lastFleetSyncTime",
    "gpmProfileCount",
  ]);

  if (!data.memberName || !data.personalToken) {
    try {
      const resp = await fetch(chrome.runtime.getURL("config.json"));
      if (resp.ok) {
        const fileCfg = await resp.json();
        await chrome.storage.local.set(fileCfg);
        data = { ...data, ...fileCfg };
      }
    } catch (e) {}
  }

  // Populate Identity Badge
  memberNameText.textContent = data.memberName || data.userEmail || "Nhân sự hệ thống";
  serverUrlText.textContent = data.serverUrl || "http://localhost:3000";

  // Populate Account Card
  if (data.latestAccount) {
    const acc = data.latestAccount;
    userHandle.textContent = acc.username ? `@${acc.username}` : "@chua_phat_hien";
    userNickname.textContent = acc.nickname || (acc.isLoggedIn ? "Đã xác minh phiên" : "Chưa đăng nhập");
    if (acc.avatarUrl) {
      userAvatar.src = acc.avatarUrl;
    }
    statFollowers.textContent = formatNumber(acc.followersCount);
    statVideos.textContent = formatNumber(acc.videoCount);
    statRevenue.textContent = formatMoney(acc.totalRevenue);

    if (acc.isLoggedIn) {
      statusPill.className = "status-pill status-active";
      statusPillText.textContent = "Đã đăng nhập";
    } else {
      statusPill.className = "status-pill status-idle";
      statusPillText.textContent = "Chưa đăng nhập";
    }
  }

  if (data.gpmProfileCount) {
    gpmProfileCount.textContent = `${data.gpmProfileCount} profiles`;
  }

  if (data.lastFleetSyncTime) {
    const d = new Date(data.lastFleetSyncTime);
    lastSyncText.textContent = `Đồng bộ lần cuối: ${d.toLocaleTimeString("vi-VN")}`;
  }

  // Display Server Sync Schedule
  function renderScheduleText(summary, intervalMinutes, autoEnabled) {
    if (!serverScheduleText) return;
    if (autoEnabled === false) {
      serverScheduleText.textContent = "Đang tắt";
      serverScheduleText.style.color = "#94a3b8";
    } else if (summary) {
      serverScheduleText.textContent = summary;
      serverScheduleText.style.color = "#38bdf8";
    } else {
      const min = intervalMinutes || 30;
      serverScheduleText.textContent = min >= 60 ? `Mỗi ${min / 60} giờ` : `Mỗi ${min} phút`;
      serverScheduleText.style.color = "#38bdf8";
    }
  }

  chrome.storage.local.get(["serverScheduleSummary", "serverIntervalMinutes", "serverAutoEnabled"], (stored) => {
    renderScheduleText(stored?.serverScheduleSummary, stored?.serverIntervalMinutes, stored?.serverAutoEnabled);
  });

  chrome.runtime.sendMessage({ type: "REFRESH_SCHEDULE" }, (res) => {
    if (res) {
      renderScheduleText(res.serverScheduleSummary, res.serverIntervalMinutes, res.serverAutoEnabled);
    }
  });

  // 2. Check Live GPM API Status
  async function checkGpmHealth() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      let res = await fetch("http://127.0.0.1:9495/api/v1/profiles?page=1&per_page=1", {
        signal: controller.signal,
      }).catch(() => null);

      if (!res || !res.ok) {
        res = await fetch("http://127.0.0.1:9495/api/v3/profiles?page=1&per_page=1", {
          signal: controller.signal,
        }).catch(() => null);
      }
      clearTimeout(timeoutId);

      if (res && res.ok) {
        gpmIndicator.className = "gpm-indicator online";
        gpmStatusText.textContent = "localhost:9495 Online";
      } else {
        throw new Error("GPM API responded with error");
      }
    } catch {
      gpmIndicator.className = "gpm-indicator offline";
      gpmStatusText.textContent = "localhost:9495 Offline";
    }
  }

  checkGpmHealth();

  // 3. Trigger Manual Sync Action
  syncNowBtn.addEventListener("click", () => {
    syncNowBtn.disabled = true;
    syncNowBtn.classList.add("spinning");
    syncBtnText.textContent = "Đang quét GPM...";

    chrome.runtime.sendMessage({ type: "TRIGGER_MANUAL_SYNC" }, (response) => {
      syncNowBtn.disabled = false;
      syncNowBtn.classList.remove("spinning");
      syncBtnText.textContent = "Đồng bộ GPM ngay";

      if (response && response.success) {
        gpmProfileCount.textContent = `${response.count} profiles`;
        const now = new Date();
        lastSyncText.textContent = `Đồng bộ lần cuối: ${now.toLocaleTimeString("vi-VN")}`;
        alert(`Đã đồng bộ thành công ${response.count} profiles về TikTokFlow Server!`);
      } else if (response && response.skipped) {
        alert(`Bỏ qua: ${response.reason}`);
      } else {
        alert("Không thể kết nối đến GPMLogin (localhost:9495). Hãy chắc chắn GPMLogin đang mở.");
      }
    });
  });
});
